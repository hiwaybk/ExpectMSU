package ExpectVMS;

use strict;
use vars qw($VERSION @ISA @EXPORT @EXPORT_OK);

require Exporter;
require AutoLoader;

@ISA = qw(Exporter AutoLoader);
@EXPORT = qw();
@EXPORT_OK = qw();
$VERSION = '0.01';

# Preloaded methods go here.

# Autoload methods go after =cut, and are processed by the autosplit program.

1;
__END__
# Below is the stub of documentation for your module. You better edit it!

=head1 NAME

ExpectVMS - Perl/Expect object to execute commands on a VMS system

=head1 SYNOPSIS

  use ExpectVMS;

=head1 DESCRIPTION

This extension provides an easy interface to execute commands
on a remote VMS system via telnet.

=head1 AUTHOR

Brian Kelly, Brian.Kelly@Montclair.edu

=head1 SEE ALSO

perl(1).

=cut
